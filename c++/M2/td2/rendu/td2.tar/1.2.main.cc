#include <iostream>
using namespace std;

int LaSolution(int x);

int main() {
  cout << LaSolution(3) << endl;
  cout << LaSolution(-1) << endl;
}
