#include "1.1.h"

int main() {
  Uint2048 x;
  Uint2048 y(123);
}
